<?php
include('../config.php');
session_start();
@$iduser=$_SESSION['id_user'];
@$ceklogin=$_SESSION['status_login'];

if ($ceklogin != 1){
  echo "
  <script>
    alert('anda belum login atau anda bukan admin');
    window.location='../Public/login.php';
  </script>";
  // header('location:../Public/login.php');
}
 ?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>NTB WEBSITE</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="../Media/Admin/css/bootstrap.min.css">
    <!-- Font Awesome -->
<!--     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    Ionicons
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css"> -->
    <!-- Theme style -->
    <link rel="stylesheet" href="../Media/Public/css/AdminLTE.min.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="../Media/Public/css/skins/_all-skins.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="../Media/Public/plugins/iCheck/flat/blue.css">
    <!-- Morris chart -->
    <link rel="stylesheet" href="../Media/Public/plugins/morris/morris.css">
    <!-- jvectormap -->
    <link rel="stylesheet" href="../Media/Public/plugins/jvectormap/jquery-jvectormap-1.2.2.css">
    <!-- Date Picker -->
    <link rel="stylesheet" href="../Media/Public/plugins/datepicker/datepicker3.css">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="../Media/Public/plugins/daterangepicker/daterangepicker-bs3.css">
    <!-- bootstrap wysihtml5 - text editor -->
    <link rel="stylesheet" href="../Media/Public/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
    <script src="../Media/Public/plugins/jQuery/jQuery-2.1.4.min.js"></script>

    <!-- FROALA -->
    <link href="../Media/Admin/froala/css/froala_editor.pkgd.min.css" rel="stylesheet" type="text/css">
    <link href="../Media/Admin/froala/css/froala_style.min.css" rel="stylesheet" type="text/css">

    <script src="../Media/Admin/froala/js/froala_editor.pkgd.min.js"></script>

    <!-- CKEDITOR -->
    <script src="../Media/Admin/ckeditor/ckeditor.js"></script>
    <script src="../Media/Admin/ckeditor/adapters/jquery.js"></script>
    <script type="text/javascript">
      $('textarea.texteditor').ckeditor();
    </script>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body class="hold-transition skin-blue">
    <div class="wrapper">
      <div class="modal fade" id="modal-pesan">
        <div class="modal-dialog">
            <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title"><i class="glyphicon glyphicon-envelope"></i>&nbsp;<b>Daftar Pesan</b></h3>
              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                &times;
              </button>
            </div><!-- /.box-header -->
            <div class="box-body">
              <div class="table-responsive">
                <table class="table no-margin"><?php
                $test=mysqli_query($koneksi, "SELECT * FROM buku_tamu");
                while($data=mysqli_fetch_array($test)) {
                ?>
              <tbody>
                <tr>
                <td style="width:25%;"><b><?php echo htmlspecialchars($data['nama']);?></b></td>
                <td><?php echo htmlspecialchars($data['pesan']);?> </td>
                </tr>
                </tbody>
              <?php
              };
              ?>
              </table>
              </div><!-- /.table-responsive -->
              </div><!-- /.box-body -->
              </div>
        </div>
      </div>

      <header class="main-header">
        <!-- Logo -->
        <a href="#" class="logo">
          <!-- logo for regular state and mobile devices -->
          <span class="logo-lg"><b>WEB</b>ku</span>
        </a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
              <li class="tasks-menu">
                <a href="#" data-target="#modal-pesan" data-toggle="modal" title="Pesan">
                  <i class="glyphicon glyphicon-envelope"></i>
                </a>
              </li>
              <li class="dropdown user user-menu">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  <img src="../Media/Public/img/IMG-20170902-WA0143.jpg" class="user-image" alt="User Image">
                  <span class="hidden-xs">Rani Rahma</span>
                </a>
                <ul class="dropdown-menu">
                  <!-- User image -->
                  <!-- Menu Body -->
                  <li class="user-body">
                    <div class="col-xs-12 text-center">
                      <a href="../Public/logout.php" class="btn btn-default btn-flat btn-block"><b>Sign out</b></a>
                    </div>
                  </li>
                </ul>
              </li>
            </ul>
          </div>
        </nav>
      </header>
