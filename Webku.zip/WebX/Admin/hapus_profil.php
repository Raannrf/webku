<?php
include ('../config.php');
$no=$_GET['no'];
$hapus=mysqli_query($koneksi, "DELETE FROM profil WHERE no_profil='$no'");
if($hapus) {
		header("location:index.php");
}
?>
