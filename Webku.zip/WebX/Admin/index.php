<?php
include ('main/header.php');
include ('main/sidebar.php');
?>
<div class="content-wrapper">
<section class="content">
<div class="row">
<div class="col-xs-12">
  <div class="box box-info">
                  <div class="box-header with-border">
                    <h3 class="box-title"><b>Daftar Artikel</b></h3>
                    <a href="profil_input.php" class="btn btn-md btn-default btn-flat pull-right"><b><i class="glyphicon glyphicon-plus"></i>&nbsp;Input Artikel</b></a>
                  </div><!-- /.box-header -->
                  <div class="box-body">
                    <div class="table-responsive">
                      <table class="table no-margin"><?php
$test=mysqli_query($koneksi, "SELECT * FROM profil");
while($data=mysqli_fetch_array($test)) {
?>
<tbody>
  <tr>
  <td><?php echo htmlspecialchars($data['judul_profil']);?> </td>
  <td class="pull-right">
    <a href="edit_profil.php?no=<?php echo $data['no_profil']; ?>" class="btn btn-primary btn-flat"><i class="glyphicon glyphicon-edit"></i></a> &nbsp;
    <a href="hapus_profil.php?no=<?php echo $data['no_profil']; ?>" class="btn btn-danger btn-flat"><i class="glyphicon glyphicon-trash"></i></a>
  </td>
  </tr>
  </tbody>
<?php
};
?>
</table>
</div><!-- /.table-responsive -->
</div><!-- /.box-body -->
</div>
</div>
</div>
</div>
<?php
include ('main/footer.php');
?>
