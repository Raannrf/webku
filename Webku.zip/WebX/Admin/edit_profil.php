<?php 
include('main/header.php');
include('main/sidebar.php');
$no=$_GET ['no'];
$tampil=mysqli_query($koneksi, "SELECT * FROM profil WHERE no_profil='$no'");
$out=mysqli_fetch_array($tampil);
?>
<div class="content-wrapper">
<section class="content">
	<div class="row">
		<div class="col-xs-12">
  			<div class="box box-info">
  				<div class="box-header with-border">
                    <h3 class="box-title"><b>Daftar Artikel</b></h3>
                </div><!-- /.box-header -->
                <div class="box-body">
					<form method="GET" action="update_profil.php">
					<input type="hidden" name="no" value="<?php echo $no; ?>" />
						<div class="form-group">
							<label>Judul	:</label>
							<input class="form-control" type="text" name="judul_profil" autocomplete="off" value="<?php echo $out['judul_profil']; ?>">
						</div>
						<div class="form-group">
						<label>Isi	:</label>
						<textarea class="form-control" rows="15" name="isi_profil"><?php echo $out['isi_profil']; ?></textarea>
						</div>
				</div>
				<div class="box-footer">
					<div class="form-group col-xs-6">
						<a href="index.php" class="btn btn-danger btn-block btn-flat">Batal</a>
					</div>
					<div class="form-group col-xs-6">
						<input  type="submit" class="btn btn-info btn-block btn-flat" value="Simpan">
					</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</section>
</div>
<?php
include('main/footer.php');
?>