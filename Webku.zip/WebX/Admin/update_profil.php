<?php
include ('../config.php');

$no=$_GET['no'];
$judul=$_GET['judul_profil'];
$isi=$_GET['isi_profil'];
if($judul==NULL){
	$non="<Tidak ada subjek>";
	$edit= mysqli_query($koneksi, "UPDATE profil SET judul_profil='$non',isi_profil='$isi' WHERE no_profil='$no'");
}else{
	$edit= mysqli_query($koneksi, "UPDATE profil SET judul_profil='$judul',isi_profil='$isi' WHERE no_profil='$no'");
}
if($edit) {
	echo "
	<script>
	alert('Berhasil diubah');
	window.location='index.php';
	</script>
	";
}else {
	echo"
	<script>
	alert('Gagal diubah');
	</script>
	";
}
?>
