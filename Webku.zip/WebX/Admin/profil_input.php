<?php 
include('main/header.php');
include('main/sidebar.php');
?>
<div class="content-wrapper">
<section class="content">
	<div class="row">
		<div class="col-xs-12">
  			<div class="box box-info">
  				<div class="box-header with-border">
                    <h3 class="box-title"><b>Daftar Artikel</b></h3>
                </div><!-- /.box-header -->
                <div class="box-body">
					<form method="GET" action="profil_proses.php">
						<div class="form-group">
							<label>Judul	:</label>
							<input class="form-control" type="text" name="judul_profil" autocomplete="off">
						</div>
						<div class="form-group">
						<label>Isi	:</label>
						<textarea id="editor" class="form-control" rows="15" name="isi_profil"></textarea>
						</div>
				</div>
				<div class="box-footer">
					<div class="form-group col-xs-6">
						<a href="index.php" class="btn btn-danger btn-block btn-flat">Batal</a>
					</div>
					<div class="form-group col-xs-6">
						<input  type="submit" class="btn btn-info btn-block btn-flat" value="Simpan">
					</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</section>
</div>
<?php
include('main/footer.php');
?>