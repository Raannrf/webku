<?php 
include('../config.php');

$judul=$_GET['judul_profil'];
$isi=$_GET['isi_profil'];
if($judul==NULL){
	$non="Tidak ada subjek";
	$test=mysqli_query($koneksi, "INSERT INTO profil(judul_profil,isi_profil) VALUES ('$non','$isi')");
}else{
	$test=mysqli_query($koneksi, "INSERT INTO profil(judul_profil,isi_profil) VALUES ('$judul','$isi')");
}

if($test) {
	echo "
	<script>
	alert('Berhasil ditambahkan');
	window.location='index.php';
	</script>
	";
}else {
	echo"
	<script>
	alert('Gagal ditambahkan');
	</script>
	";
}
?>

