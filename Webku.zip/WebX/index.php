<?php
header('location:Public/');
?>