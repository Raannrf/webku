<?php
include('main/header.php');
$id_konten = $_GET['guk'];
$query = mysqli_query($koneksi,"SELECT * FROM profil WHERE no_profil='$id_konten'");
$data = mysqli_fetch_array($query);
?>
<!--------------Content--------------->
<section class="container">
	<div class="zerogrid">
		<div class="col-2-3">
			<div id="main-content" class="wrap-col">
				<article class="single">
					<img class="full" src="../Media/Public/img/Rumah-Tradisional-Sumba.jpg">
					<div class="wrap-art">
						<div class="art-header">
							<h1 class="title"><a href="#"><?php echo $data['judul_profil']; ?></a></h1>
						</div>
						<div class="art-content">
							<?php echo $data['isi_profil']; ?>
						</div>
						&nbsp;
						<hr/>
						<div class="art-footer">
							<center>
							<div class="row">
								<div class="content-social">
									<a href="#"><img src="../Media/Public/img/facebook2.png" title="facebook"/></a>
									<a href="#"><img src="../Media/Public/img/twitter2.png" title="twitter"/></a>
									<a href="#"><img src="../Media/Public/img/google2.png" title="google"/></a>
									<a href="#"><img src="../Media/Public/img/pinterest2.png" title="pinterest"/></a>
									<a href="#"><img src="../Media/Public/img/instagram2.png" title="instagram"/></a>
								</div>
							</div>
							</center>						
						</div>
					</div>
				</article>
			</div>
		</div>
<?php
include('main/sidebar.php');
?>
	</div>
</section>
<?php
include('main/footer.php');
?>