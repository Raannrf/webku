<?php
include('main/header.php');
?>
<section class="container ">
	<div class="zerogrid">
		<div class="col-3-3">
			<div id="main-content" class="wrap-col">
				<div class="wrap-content">
					<article class="single">
						<div class="wrap-art">
							<div class="art-header">
								<h1 class="title"><a href="#">Contact Us</a></h1>
							</div>
							<div class="art-content">
								<div id="contact_form">
									<h3>Halo !! Anda dapat mengirim pesan kepada kami.</h3>
									<p>[Siap digunakan] Hi semua  !! Pengunjung dapat menggunakan kontak formulir ini untuk mengirim pesan kepada kami.Buka file contact.php dan ubah email Anda.</p>
									<form name="form1" id="ff" method="post" action="insert_contact.php">
										 <label>
										 Nama:
										 <input type="text" placeholder="Masukan nama Anda" name="nama" id="name" required>
										 </label>
									 
										 <label>
										 Email:
										 <input type="email" placeholder="Masukan email Anda@gmail.com" name="email" id="email" required>
										 </label>
											
										 <label>
										 Pesan:
										 <textarea name="pesan" id="Pesan" placeholder="Masukan pesan Anda di sini"></textarea>
										 </label>
									 
										 <center>
										 	<input class="sendButton" type="submit" name="Submit" value="Send">
										 </center>
										 
									</form>
								</div>
							</div>
						</div>
					</article>
				</div>
			</div>
		</div>
	</div>
</section>
<?php
include('main/footer.php');
?>