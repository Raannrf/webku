<?php
include('main/header.php');
?>
<!--------------Content--------------->
<section class="container">
	<div class="zerogrid">
		<div class="col-3-3">
			<div id="main-content" class="wrap-col">
				<article>
					<div class="art-related">
						<div class="wrap-art-related">
							<h1 class="title"><a href="#">Sekedar menyelesaikan tugas Pak Lulu</a></h1>
							<div class="row">
							</div>
						</div>
					</div>
				</article>
			</div>
		</div>
	</div>
</section>
<?php
include('main/footer.php');
?>