<div class="col-1-3">
	<div id="sidebar" class="wrap-col">
		<div class="wrap-slidebar" style="padding-bottom: 300px;">
			<div class="widget wid-gallery">
				<div class="wid-header">
					<h4>Galeri</h4>
					<div class="clear"></div>
				</div>
				<div class="wid-content">
					<div class="col-1-3">
						<a href="#"><img src="../Media/Public/img/home-slider-masjidrayantb-2.jpg"></a>
						<a href="#"><img src="../Media/Public/img/kenawa2jpg-4UjH.jpg"></a>
						<a href="#"><img src="../Media/Public/img/Kenawa-Island-Sumbawa.jpg"></a>
						<a href="#"><img src="../Media/Public/img/komodo.jpg"></a>
				    </div>
				    <div class="col-1-3">
						<a href="#"><img src="../Media/Public/img/laut tersembunyi.jpg"></a>
						<a href="#"><img src="../Media/Public/img/moyo.jpg"></a>
						<a href="#"><img src="../Media/Public/img/ntb-bakal-didatangi-40-kapal-perang-dari-35-negara-ada-apa-170920y_3x2.jpg"></a>
						<a href="#"><img src="../Media/Public/img/Picture 086.jpg"></a>
				    </div>
				    <div class="col-1-3">
						<a href="#"><img src="../Media/Public/img/poto tono.jpg"></a>
						<a href="#"><img src="../Media/Public/img/pulau-kanawa.jpg"></a>
						<a href="#"><img src="../Media/Public/img/resort.jpg"></a>
						<a href="#"><img src="../Media/Public/img/sembalun_lawang_lombok.jpg"></a>
				    </div>
				</div>
			</div>
		</div>
	</div>
</div>