
<!--------------Footer--------------->
<footer>
	<div class="zerogrid">
	   <div class="col-2-3">
			<div class="back-to-top">
				<a href="#">Back to top</a>
			</div>
	   </div>
	   <div class="col-1-3">
			<div class="row">
				<div class="footer-social">
					<a href="#"><img src="../Media/Public/img/facebook.png" title="facebook"/></a>
					<a href="#"><img src="../Media/Public/img/twitter.png" title="twitter"/></a>
					<a href="#"><img src="../Media/Public/img/google.png" title="google"/></a>
					<a href="#"><img src="../Media/Public/img/pinterest.png" title="pinterest"/></a>
					<a href="#"><img src="../Media/Public/img/instagram.png" title="instagram"/></a>
				</div>
			</div>
	   </div>
	</div>
</footer>

</div>
<script type="text/javascript" src="../Media/Public/js/jquery.min.js"></script>
<script type="text/javascript" src="../Media/Public/js/navigation.js"></script>

</body>
</html>