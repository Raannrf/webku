<?php
include('main/header.php');
?>
<!--------------Content--------------->
<section class="container">
	<div class="zerogrid">
		<div class="col-2-3">
			<div id="main-content">
				<div class="row">
					<?php
					$query = mysqli_query($koneksi,"SELECT * FROM profil ORDER BY no_profil DESC");
					while($data = mysqli_fetch_array($query)){
					?>
					<div class="col-1-2">
						<div class="wrap-col">
							<article>
								<img class="full" src="../Media/Public/img/Rumah-Tradisional-Sumba.jpg">
								<div class="wrap-content">
									<div class="art-header">
										<h1 class="title"><a href="#"><?php echo $data['judul_profil']; ?></a></h1>
									</div>
									<div class="art-content">
										<p><?php echo substr($data['isi_profil'],0,100); ?></p>
										<div class="row">
											<div class="content-social">
												<a href="#"><img src="../Media/Public/img/facebook2.png" title="facebook"/></a>
												<a href="#"><img src="../Media/Public/img/twitter2.png" title="twitter"/></a>
												<a href="#"><img src="../Media/Public/img/google2.png" title="google"/></a>
												<a href="#"><img src="../Media/Public/img/pinterest2.png" title="pinterest"/></a>
												<a href="#"><img src="../Media/Public/img/instagram2.png" title="instagram"/></a>
											</div>
										</div>
										<center><a href="single.php?guk=<?php echo $data['no_profil'] ?>" class="button">Read More</a></center>
									</div>
								</div>
							</article>
						</div>
					</div>
					<?php
					};
					?>
				</div>
			</div>
		</div>
<?php
include('main/sidebar.php');
?>
	</div>
</section>
<?php
include('main/footer.php');
?>