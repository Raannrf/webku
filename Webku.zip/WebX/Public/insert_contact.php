<?php
include('../config.php');
$nama = $_POST['nama'];
$email = $_POST['email'];
$pesan = $_POST['pesan'];

$query = mysqli_query($koneksi,"
	INSERT INTO buku_tamu
	SET
	nama = '$nama',
	email = '$email',
	pesan = '$pesan'
	");

if($query) {
	echo "
	<script>
	alert('Berhasil dikirim');
	window.location='contact.php';
	</script>
	";
}else {
	echo"
	<script>
	alert('Gagal dikirim');
	</script>
	";
}

